//might have to nest this in game function

class Iterations {
	private int iterate;

	//set default iterations
	public Iterations() {
		iterate = 5;
	}

	//set user-specified iterations
	public Iterations(int iterate) {
		this.iterate = iterate;
	}

	public void setIterations(Lion lion, String [][] grid, String [][] setGrid) {
		if (iterate > 500) {
			System.out.println("This iteration amount is too high!");
		}
		else if (iterate < 5) {
			System.out.println("This iteration amount is too low!");
		}
		else {
			System.out.println("Year: 0");
			setGrid = lion.setPopulation(grid);
			System.out.println();

			for (int i = 0; i < iterate; i++) {
				System.out.println("Year: " + (i+1));
		
				lion.nextIteration(setGrid);
				System.out.println();
			}
		}
	}
}

class IterationsTester {
	public static void main (String [] args) {
		Lion lion = new Lion();

		Grid userGrid = new Grid(5);
		int size = userGrid.getSize();

		String [][] grid = new String [size][size];
		String [][] setGrid = new String [size][size];
		grid = userGrid.makeGrid();

		Iterations userIterations = new Iterations();
		userIterations.setIterations(lion, grid, setGrid); 
	}
}