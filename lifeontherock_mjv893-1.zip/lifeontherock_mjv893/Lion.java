import java.util.Random;

class Lion {
	private int age;
	private double lionPopulate;
	private double lionBirth;
	private boolean die;
	private boolean birth;

	public Lion() {
		age = 0;
		lionPopulate = 0.08;
		lionBirth = 0.05;
		die = false;
		birth = false;
	}

	public Lion (double lionPopulate, double lionBirth) {
		age = 0;
		this.lionPopulate = lionPopulate;
		this.lionBirth = lionBirth;
		die = false;
		birth = false;
	}

	public int addAge() {
		age += 1;
		return age;
	}

	public boolean toDie() {
		if (age > 4) {
			die = true;
		}
		return die;
	}

	public boolean giveBirth() {
		if (age > 4) {
			birth = true;
		}
		return birth;
	}

	public String [][] setPopulation(String [][] grid) {
		double toPopulate = grid.length * lionPopulate;

		for (int row = 0; row < grid.length; row++) {
			for (int column = 0; column < grid[row].length; column++) {
				if (lionPopulate > 0.10) {
					System.out.println("That population count is too high!");
				}
				else if (lionPopulate < 0.0) {
					System.out.println("That population count is too low!");
				} 
				else {
					for (int i = 0; i < toPopulate; i++) {
						Random generator = new Random();
						int randomIndex = generator.nextInt(grid.length);

						if (grid[i] == grid[randomIndex]) {
							grid[row][column] = "1";
							System.out.print(age + "L\t");															
						}
						else {
							grid[row][column] = "0";
							System.out.print("**\t");										
						}
					}
				}
			}
			System.out.println();
		}
		return grid;
	}

	public String[][] setBirth(String[][] grid) {
		double toBirth = grid.length * lionBirth;

		for (int row = 0; row < grid.length; row++) {
			for (int column = 0; column < grid[row].length; column++) {
				if (lionBirth > 0.15) {
					System.out.println("That birth rate is too high!");
				}
				else if (lionBirth < 0.01) {
					System.out.println("That birth rate is too low!");
				} 
				else {
					for (int i = 0; i < toBirth; i++) {
						Random generator = new Random();
						int randomIndex = generator.nextInt(grid.length);
						
						if (grid[i] == grid[randomIndex]) {
							grid[row][column] = "1";
							age = 0;
						}
					}
				}
			}
		}
		return grid;
	}

	public void nextIteration(String [][] grid) {
		addAge();
		toDie();
		giveBirth();

		String [][] next = new String [grid.length][grid.length];
		double toBirth = grid.length * lionBirth;

		for (int row = 0; row < grid.length; row++) {
			for (int column = 0; column < grid[row].length; column++) {
				/*if (birth == true) {
					if (lionBirth > 0.15) {
						System.out.println("That birth rate is too high!");
					}
					else if (lionBirth < 0.01) {
						System.out.println("That birth rate is too low!");
					} 
					else {
						for (int i = 0; i < toBirth; i++) {

						}
					}
				}
				else*/ if (die == true) {
					grid[row][column] = "0";
				}
				else {
					next[row][column] = grid[row][column];
				}
			}
		}

		for (int row = 0; row < next.length; row++) {
			for (int column = 0; column < next[row].length; column++) {
				if (grid[row][column] == "1") {
					System.out.print(age + "L\t");
				} else {
					System.out.print("**\t");					
				}
			}
			System.out.println();
		}
	}
}

class LionTester {
	public static void main (String [] args) {
		String [][] grid = new String [5][5];

		Lion lion = new Lion();
		grid = lion.setPopulation(grid);

		lion.nextIteration(grid);
		lion.nextIteration(grid);
		lion.nextIteration(grid);
		lion.nextIteration(grid);
		lion.nextIteration(grid);
		lion.nextIteration(grid);

	}
}