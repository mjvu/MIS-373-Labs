class Game {
	public static void main (String [] args) {
		//NOTE: everything is currently set to their defaults

		//USER: input grid size in parenthesis
		Grid userGrid = new Grid();

		//create grid based on user input
		int size = userGrid.getSize();
		String [][] grid = new String [size][size];
		String [][] setGrid = new String [size][size];
		grid = userGrid.makeGrid();

		//USER: input lion cell count in decimals in parenthesis (ex. 8% = 0.08)
		Lion lion = new Lion();

		//USER: input number of iterations in parenthesis
		Iterations userIterations = new Iterations();

		//iterate through game based on user input
		userIterations.setIterations(lion, grid, setGrid);

		
	}
}