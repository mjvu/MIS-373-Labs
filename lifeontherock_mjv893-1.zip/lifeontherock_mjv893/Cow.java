import java.util.Random;

class Cow {
	private int age;
	private double cowPopulate;
	private double cowBirth;
	private boolean die;
	private boolean birth;

	public Cow() {
		age = 0;
		cowPopulate = 0.20;
		cowBirth = 0.15;
		die = false;
		birth = false;
	}

	public Cow (double cowPopulate, double cowBirth) {
		age = 0;
		this.cowPopulate = cowPopulate;
		this.cowBirth = cowBirth;
		die = false;
		birth = false;
	}

	public int addAge() {
		age += 1;
		return age;
	}

	public boolean toDie() {
		if (age > 3) {
			die = true;
		}
		return die;
	}

	public boolean giveBirth() {
		if (age == 3) {
			birth = true;
		}
		return birth;
	}

	public String [][] setPopulation(String [][] grid) {
		double toPopulate = grid.length * cowPopulate;

		for (int row = 0; row < grid.length; row++) {
			for (int column = 0; column < grid[row].length; column++) {
				if (cowPopulate > 0.30) {
					System.out.println("That population count is too high!");
				}
				else if (cowPopulate < 0.0) {
					System.out.println("That population count is too low!");
				} 
				else {
					for (int i = 0; i < toPopulate; i++) {
						Random generator = new Random();
						int randomIndex = generator.nextInt(grid.length);

						if (grid[i] == grid[randomIndex]) {
							grid[row][column] = "1";
							System.out.print(age + "C\t");															
						}
						else {
							grid[row][column] = "0";
							System.out.print("**\t");										
						}
					}
				}
			}
			System.out.println();
		}
		return grid;
	}

	public void nextIteration(String [][] grid) {
		addAge();
		toDie();
		giveBirth();

		String [][] next = new String [grid.length][grid.length];

		for (int row = 0; row < grid.length; row++) {
			for (int column = 0; column < grid[row].length; column++) {
				if (die == true) {
							grid[row][column] = "0";
						}
						else {
							next[row][column] = grid[row][column];
						}
					}
				}

		for (int row = 0; row < next.length; row++) {
			for (int column = 0; column < next[row].length; column++) {
				if (grid[row][column] == "1") {
					System.out.print(age + "C\t");
				} else {
					System.out.print("**\t");					
				}
			}
			System.out.println();
		}
	}
}

class CowTester {
	public static void main (String [] args) {
		String [][] grid = new String [5][5];

		Cow cow = new Cow();
		grid = cow.setPopulation(grid);

		cow.nextIteration(grid);
	}
}