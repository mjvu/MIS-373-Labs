class Grid {
	private int size;

	public Grid() {
		//set default grid
		size = 7;
	}

	public Grid(int size) {
		//set user specified grid
		this.size = size;
	}

	public int getSize () {
		return size;
	}

	public String [][] makeGrid () {
		String [][] grid = new String [size][size];

		if (grid.length > 10) {
			System.out.println("This grid size is too large!");
		}
		else if (grid.length < 5) {
			System.out.println("This grid size is too small!");
		}
		else {
			for (int row = 0; row < grid.length; row++) {
				for (int column = 0; column < grid[row].length; column++) {
					if (grid[row][column] == null) {
						grid[row][column] = "0";
					}
				}
				System.out.println();
			}
		}
		return grid;
	}

}

/*class GridTester {
	public static void main (String [] args) {
		Grid userGrid = new Grid();
		userGrid.MakeGrid();
	}
}*/