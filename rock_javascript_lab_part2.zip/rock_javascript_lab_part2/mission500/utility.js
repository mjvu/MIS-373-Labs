// Anytime you need a date, you are required to call
// this function to get a date.
function getDate() {
	var settings = JSON.parse(localStorage.getItem('settings'));
	if (settings && settings.useTestDate && settings.testYear && settings.testMonth && settings.testDay) {
		var testDateAsString = settings.testYear + " " + settings.testMonth + " " + settings.testDay;
		return new Date (testDateAsString);
	} else {
		return new Date();
	}
}

// You can add more date functions that reference the
// one above to get a date.
// You can also add all your other 
// utility functions below here.

function getDay() {
	var now = getDate(),
	start = new Date(now.getUTCFullYear(), 0, 0),
	difference = now - start,
	oneDay = 1000 * 60 * 60 * 24,
	day = Math.round(difference / oneDay);
	return day;
}

var monthsAndDays = {};
monthsAndDays[0] = [31];
monthsAndDays[1] = [28];
monthsAndDays[2] = [31];
monthsAndDays[3] = [30];
monthsAndDays[4] = [31];
monthsAndDays[5] = [30];
monthsAndDays[6] = [31];
monthsAndDays[7] = [31];
monthsAndDays[8] = [30];
monthsAndDays[9] = [31];
monthsAndDays[10] = [30];
monthsAndDays[11] = [31];

function populateTestDates() {
	var testDay = document.getElementById("testDay"),
	testMonth = document.getElementById("testMonth"),
	testYear = document.getElementById("testYear"),
	today = getDate(),
	year = today.getUTCFullYear();

	for (var i = 0; i < 21; i++) {
		testYear.options[testYear.options.length] = new Option(i + year, i);
	}

	for (var i = 0; i < 12; i++) {
		testMonth.options[testMonth.options.length] = new Option(i + 1, i);
	}

	var selectedMonth = testMonth.options[testMonth.selectedIndex].value;

	while (testDay.options.length) {
		testDay.remove(0);
	}

	var months = monthsAndDays[selectedMonth];

	for (var i = 0; i <= (months[0] - 1); i++) {
		testDay.options[testDay.options.length] = new Option(i + 1, i);
	}
}


function setChapterOptions(id, n) {
	var chapter = document.getElementById(id);

	for (var i = 0; i < n; i++) {
		chapter.options[chapter.options.length] = new Option(i + 1, i);
	}
}

function setBibleBookDetails() {
	var book = document.getElementById("bible_book");

	for(var i in bible_book_details.books) {
		book.options[book.options.length] = new Option(bible_book_details.books[i].book, i);
	}

}

function changeBookChapters() {
	var bookList = document.getElementById("bible_book"),
	chapterList = document.getElementById("bible_book_chapter"),
	selectedBook = bookList.selectedIndex;

	while (chapterList.options.length) {
		chapterList.remove(0);
	}

	var books = bible_book_details.books[selectedBook].chapters;

	var chapters = setChapterOptions("bible_book_chapter", books);
}