function focusOnLoad() {
	document.getElementById("firstName").focus();
}

function handleSaveButton() {
	var setFirstName = document.getElementById("firstName").value,
	setLastName = document.getElementById("lastName").value,
	setEmail = document.getElementById("email").value;

	var user = {};
	user.firstName = setFirstName;
	user.lastName = setLastName;
	user.email = setEmail;

	var users = [];
	users.push(user);

	localStorage.setItem("usersInLocalStorage", JSON.stringify(users));

	addNewRecord();
}

function addNewRecord() {
	var storedUsers = JSON.parse(localStorage.getItem("usersInLocalStorage"));
	
	for (var i in storedUsers) {

		var newRow = document.createElement("div");
		newRow.setAttribute("class", "row");

		var newCell1 = document.createElement("div")
		newCell1.textContent = storedUsers[i].firstName;
		newCell1.setAttribute("class", "cell");

		var newCell2 = document.createElement("div")
		newCell2.textContent = storedUsers[i].lastName;
		newCell2.setAttribute("class", "cell");

		var newCell3 = document.createElement("div")
		newCell3.textContent = storedUsers[i].email;
		newCell3.setAttribute("class", "cell");

		newRow.appendChild(newCell1);
		newRow.appendChild(newCell2);
		newRow.appendChild(newCell3);
		
		var div = document.getElementById("localStorageContactsDisplay");
		div.appendChild(newRow);
	}
}

window.onload = focusOnLoad;
var saveButton = document.getElementById("contactForm");
saveButton.onclick = handleSaveButton;