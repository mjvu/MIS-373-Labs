class Mjv893_GradeCalculator {
	private double exam1_Score;
	private double exam2_Score;
	private double exam3_Score;
	private double totalHomework_Score;
	private double ttotalQuizzes_Score;

	public Mjv893_GradeCalculator (double exam1_Score, double exam2_Score, double exam3_Score, 
									double totalHomework_Score, double ttotalQuizzes_Score) {
		if (exam1_Score < 0 || exam1_Score > 100 || exam2_Score < 0 || exam2_Score > 100 ||
			exam3_Score < 0 || exam3_Score > 100 || totalHomework_Score < 0 || totalHomework_Score > 100 ||
			ttotalQuizzes_Score < 0 || ttotalQuizzes_Score > 100) {
			System.out.println("This is not a valid score");
		} else {
			this.exam1_Score = exam1_Score;
			this.exam2_Score = exam2_Score;
			this.exam3_Score = exam3_Score;
			this.totalHomework_Score = totalHomework_Score;
			this.ttotalQuizzes_Score = ttotalQuizzes_Score;
		}
	}

	public void calculateGrade() {
		double exam1_Weight = 0.25;
		double exam2_Weight = 0.25;
		double exam3_Weight = 0.25;
		double totalHomework_Weight = 0.10;
		double totalQuizzes_Weight = 0.15;

		double weightedAverage = (exam1_Score * exam1_Weight) +
					(exam2_Score * exam2_Weight) +
					(exam3_Score * exam3_Weight) +
					(totalHomework_Score * totalHomework_Weight) +
					(ttotalQuizzes_Score * totalQuizzes_Weight);

		if (weightedAverage > 90) {
			System.out.println("Your final grade is an A.");
		} else if (weightedAverage > 80) {
			System.out.println("Your final grade is an B.");
		} else if (weightedAverage > 70) {
			System.out.println("Your final grade is an C.");
		} else if (weightedAverage > 60) {
			System.out.println("Your final grade is an D.");
		} else {
			System.out.println("Your final grade is an F.");
		}
	}
}