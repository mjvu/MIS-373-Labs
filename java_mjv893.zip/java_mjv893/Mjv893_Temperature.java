class Mjv893_Temperature {
	private double fTemp;
	private double cTemp;

	public Mjv893_Temperature() {
		fTemp = 0;
		cTemp = 0;
	}

	public void setFahrenheit (double fTemp) {
		this.fTemp = fTemp;
	}

	public void setCelsius (double cTemp) {
		this.cTemp = cTemp;
	}

	public double getAsFahrenheit () {
		fTemp = (9/5) * (cTemp + 32);
		System.out.println(cTemp + "C converts to " + fTemp + "F");
		return fTemp;
	}

	public double getAsCelsius () {
		cTemp = (5/9) * (fTemp - 32);
		System.out.println(fTemp + "F converts to " + cTemp + "C");
		return cTemp;
	}
}