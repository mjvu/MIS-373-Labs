interface Mjv893_Sellable {
	public int getPrice ();
	public String getName ();
}