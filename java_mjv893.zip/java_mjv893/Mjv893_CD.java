class Mjv893_CD {
	private double balance;
	double interestRate = 0.07;

	public Mjv893_CD(double balance) {
		this.balance = balance;
	}

	public void addAnnualInterest() {
		double interestAmount = balance * interestRate;
		balance += interestAmount;

		System.out.println("$" + interestAmount + " of interest has been added");
		System.out.println("Your current balance is now $" + balance);
		System.out.println();
	}

	public void getBalance() {
		System.out.println("The balance is $" + balance);
		System.out.println();
	}
}