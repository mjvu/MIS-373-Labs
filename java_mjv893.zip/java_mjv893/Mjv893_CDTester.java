class Mjv893_CDTester {
	public static void main (String [] args) {
		Mjv893_CD c1 = new Mjv893_CD(150070.38);

		c1.getBalance();

		c1.addAnnualInterest();
		c1.addAnnualInterest();
	}
}