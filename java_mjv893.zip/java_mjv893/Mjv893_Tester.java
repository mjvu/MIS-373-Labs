import java.util.ArrayList;

public class Mjv893_Tester {
	public static void main (String [] args) {
		System.out.println("------------------------------");
		Mjv893_Product p1 = new Mjv893_Product ("Bling Bling Jeans", 100);
		Mjv893_Event e1 = new Mjv893_Event ("Fashion Training", 5, 200);

		Mjv893_Shopping_Cart cart = new Mjv893_Shopping_Cart();
		cart.addItemToCart(p1);
		cart.addItemToCart(e1);
		cart.printToScreen();
		System.out.println("------------------------------");
		ArrayList items = new ArrayList();
		items.add(new Mjv893_Product ("Dance Video", 50));
		items.add(new Mjv893_Event ("Rumba Class", 5, 100));
		items.add(p1);
		items.add(e1);
		Mjv893_Shopping_Cart cart2 = new Mjv893_Shopping_Cart(items);
		cart2.printToScreen();
		System.out.println("------------------------------");
	}
}