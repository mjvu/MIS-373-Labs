class Mjv893_LotteryWinner {
	private int [] winningLotteryNumbers = new int [5];

	public Mjv893_LotteryWinner() {
		winningLotteryNumbers[0] = 10;
		winningLotteryNumbers[1] = 20;
		winningLotteryNumbers[2] = 30;
		winningLotteryNumbers[3] = 40;
		winningLotteryNumbers[4] = 50;
	}

	public void checkWinnings(int [] myLotteryPicks) {
		int matches = 0;

		for (int i = 0; i < myLotteryPicks.length; i++) {
			
			for (int j = 0; j < winningLotteryNumbers.length; j++) {
				
				if (winningLotteryNumbers[j] == myLotteryPicks[i]) {
					matches = matches + 1;
				} 
			}
		}

		if (matches == 0) {
			System.out.println("You got no matches.");
		} else {
			System.out.println("You got " + matches + " matches.");
		}

		if (matches == 1) {
			System.out.println("You won $10!");
			System.out.println();
		} else if (matches == 2) {
			System.out.println("You won $25!");
			System.out.println();
		} else if (matches == 3) {
			System.out.println("You won $50!");
			System.out.println();
		} else if (matches == 4) {
			System.out.println("You won $1,000!");
			System.out.println();
		} else if (matches == 5) {
			System.out.println("You won $10,000!");
			System.out.println();
		} else {
			System.out.println("You won $0!");
			System.out.println();
		}
	}
}