class Mjv893_BankTester {
	public static void main (String [] args) {
		Mjv893_BankAccount a1 = new Mjv893_BankAccount("Savings");
		Mjv893_BankAccount a2 = new Mjv893_BankAccount("Checking");

		a1.depositMoney(10250.67);
		a2.depositMoney(217.38);

		a1.depositMoney(2222.22);
		a2.withdrawMoney(220);

		a2.getBalance();
	}
}