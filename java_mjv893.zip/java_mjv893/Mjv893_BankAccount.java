class Mjv893_BankAccount {
	private double balance;
	private String accountName;

	public Mjv893_BankAccount(String accountName) {
		balance = 0;
		this.accountName = accountName;
	}

	public void depositMoney(double amount) {
		if (amount <= 0) {
			System.out.println("This is not a valid desposit amount.");
			System.out.println();
		} else {
			balance += amount;

			System.out.println("You desposited $" + amount);
			System.out.println("Your balance is now $" + balance);
			System.out.println();
		}
	}

	public void withdrawMoney(double amount) {
		if (amount > balance) {
			System.out.println("You do not have the appropriate funds to withdraw this amount.");
			System.out.println();
		} else {
			balance -= amount;

			System.out.println("You withdrew $" + amount);
			System.out.println("Your balance is now $" + balance);
			System.out.println();
		}
	}

	public void getBalance() {
		System.out.println("The balance for " + accountName + " is $" + balance);
		System.out.println();
	}
}