import java.util.ArrayList;

class Mjv893_Shopping_Cart {
	private static ArrayList items;
	private static int cartItemCount;
	private static int cartTotalPrice;

	public Mjv893_Shopping_Cart () {
		items = new ArrayList();
		cartTotalPrice = 0;
		cartItemCount = 0;
	}

	public Mjv893_Shopping_Cart (ArrayList itemsPassedIn) {
		this();
		for (Object cartItemObject : itemsPassedIn) {
			Mjv893_Sellable item = (Mjv893_Sellable) cartItemObject;
			addItemToCart(item);
		}
	}

	public void addItemToCart (Mjv893_Sellable item) {
		items.add(item);
		System.out.println("Added " + item.getName() + " costing $" + item.getPrice() + " to cart.");
	}

	public static int getCartItemCount () {		
		cartItemCount = items.size();
		
		return cartItemCount;
	}

	public static int getCartTotalPrice () {
		for (Object cartItemObject : items) {
			Mjv893_Sellable item = (Mjv893_Sellable) cartItemObject;
			cartTotalPrice = cartTotalPrice + item.getPrice();
		} 
		return cartTotalPrice;
	}

	public void printToScreen () {
		System.out.println("Number of cart items is: " + Mjv893_Shopping_Cart.getCartItemCount());
		System.out.println("Total price of cart items is: $" + Mjv893_Shopping_Cart.getCartTotalPrice());
	}
}