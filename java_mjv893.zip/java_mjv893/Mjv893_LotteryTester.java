class Mjv893_LotteryTester {
	public static void main (String [] args) {
		Mjv893_LotteryWinner l1 = new Mjv893_LotteryWinner();

		int[] picks1 = {10, 20, 30, 100, 200};
		l1.checkWinnings(picks1);

		int[] picks2 = {10, 20, 30, 40, 50};
		l1.checkWinnings(picks2);

		int[] picks3 = {1, 2, 3, 4, 5};
		l1.checkWinnings(picks3);
	}
}