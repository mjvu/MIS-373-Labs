class Mjv893_GradeCalcTester {
	public static void main (String [] args) {
		Mjv893_GradeCalculator g1 = new Mjv893_GradeCalculator(89, 93, 90, 100, 65);

		g1.calculateGrade();
	}
}