class Mjv893_Event implements Mjv893_Sellable {
	private String name;
	private int days;
	private int pricePerDay;

	public Mjv893_Event (String name, int days, int pricePerDay) {
		this.name = name;
		this.days = days;
		this.pricePerDay = pricePerDay;
	}

	public int getPrice() {
		return days * pricePerDay;
	}

	public String getName() {
		return name;
	}
}