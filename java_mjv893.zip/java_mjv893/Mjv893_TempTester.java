class Mjv893_TempTester {
	public static void main (String [] args) {
		Mjv893_Temperature t1 = new Mjv893_Temperature();
		Mjv893_Temperature t2 = new Mjv893_Temperature();

		//convert fahrenheit temp to celsius
		t1.setFahrenheit(32);
		t1.getAsCelsius();

		//convert celsius temp to fahrenheit
		t2.setCelsius(0);
		t2.getAsFahrenheit();
	}
}