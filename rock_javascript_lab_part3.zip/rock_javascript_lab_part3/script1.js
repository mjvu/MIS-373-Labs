var songs1 = [
{videoId: 'oBH6Q_wJPNs' , startSeconds:'45', endSeconds:'50'},
{videoId: 'yT7AFdvXjS8' , startSeconds:'45', endSeconds:'49'},
{videoId: 'BrgPzp0GBcw' , startSeconds:'74', endSeconds:'78'},
{videoId: 'Y_tIbFIIiNo' , startSeconds:'80', endSeconds:'85'}
];


//[0] = pull up; 					3:10
//[1] = one girl					4:06
//[2] = evacuate the dance floor	5:43
//[3] = high voltage dance			4:25