<html>
<head>
</head>
<body>

<?php
        //make outbound call
        require '/root/telephony/twilio-php-master/Services/Twilio.php';

        $sid = 'ACf08422cd5895309e8d2e2b3dee3a5f42';
        $token = '51daebca9bc78358651347c0070fdeda';
        $phonenumber = '2053081583';
        $usernumber = $_GET['Digits'];

        $client = new Services_Twilio($sid, $token);

        try {
                $call = $client->account->calls->create(
                        $phonenumber,
                        $usernumber,
                        'http://104.239.142.69/jenniferv/outbound_call_script.php'
                );
                echo 'Started call: ' . $usernumber;
                echo "<br>";
        } catch (Exception $e) {
                echo 'Error: ' . $e->getMessage();
        }

        //update phone_call_completed
        $id = $_GET['call_id'];

        $servername = "localhost";
        $username = "jenniferv";
        $password = "mjv893";
        $dbname = "db_jenniferv";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
        }
        $sql = "UPDATE tbl_call_queue SET phone_call_completed='Y' WHERE phone_call_id=$id";
        //check to see if record is updated successfully
        if ($conn->query($sql) === TRUE) {
                echo " ";
        } else {
                echo "Error updating record: " . $conn->error;
        }
        $conn->close();

        //display link
        echo "<br>";
        echo "<a href=display_call_queue.php>Go back to the queue</a>";
?>

</body>
</html>
