<?php
        header('Content-type: text/xml');
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<Response>';
        $user_pushed = (int) $_REQUEST['Digits'];

        $servername = "localhost";
        $username = "jenniferv";
        $password = "mjv893";
        $dbname = "db_jenniferv";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
        }
        $sql = "INSERT INTO tbl_call_queue (phone_call_number) VALUES (" . $user_pushed . ")";
        if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
        } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();

        echo '<Say>The next available representative will call you back shortly.</Say>';
        echo '<Say>Thank you for flying Southwest Airlines.</Say>';
        echo '<Say>Enjoy the rest of your day.</Say>';

        echo '</Response>';
?>
