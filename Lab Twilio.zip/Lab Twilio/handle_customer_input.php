<?php
        header('Content-type: text/xml');
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        echo '<Response>';
        $user_pushed = (int) $_REQUEST['Digits'];

        if ($user_pushed == 1) {
                echo '<Gather action="store_customer_number.php" numDigits="10">';
                echo '<Say>Please enter your 10 digit phone number."</Say>';
                echo '</Gather>';
        } else if ($user_pushed == 9) {
                echo '<Say>Thank you for flying Southwest Airlines.</Say>';
                echo '<Say>Enjoy the rest of your day.</Say>';
        } else {
                echo '<Redirect>welcome_customer.php</Redirect>';
        }
        echo '</Response>';
?>
