<html>
<head>
<title>Southwest Airlines Customer Service</title>
<style>
table, th, td {
        border: 1px solid black;
}
</style>
</head>
<body>
<h1>Display Call Queue</h1>

<?php
        $servername = "localhost";
        $username = "jenniferv";
        $password = "mjv893";
        $dbname = "db_jenniferv";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT phone_call_number, phone_call_id FROM tbl_call_queue WHERE phone_call_completed='N' ORDER BY phone_call_creation_date";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
                echo "<table><tr><th>Customer Number</th></tr>";
                while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo '<td><a href="generate_outbound_call.php?Digits=' .$row['phone_call_number'].'&call_id=' .$row['phone_call_id'].'">'.$row['phone_call_numb$
                        echo "</tr>";
                }
                echo "</table>";
        } else {
                echo "0 results";
        }
        $conn->close();

        echo '</Response>';
?>
</body>
</html>