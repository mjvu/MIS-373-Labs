<?php
        header('Content-type: text/xml');
        echo '<?xml version="1.0" encoding="UTF-8"?>';
?>

<Response>
        <Say>Thank you for flying Southwest.</Say>
        <Say>We are returning your call and will now transfer you to a customer service representative.</Say>
</Response>
