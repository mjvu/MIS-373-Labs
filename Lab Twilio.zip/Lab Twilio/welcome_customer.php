<?php
        header('Content-type: text/xml');
        echo '<?xml version="1.0" encoding="UTF-8"?>';
?>

<Response>
        <Gather action="handle_customer_input.php" numDigits="1">
                <Say>Welcome to Southwest Airlines.</Say>
                <Say>Due to high call volume, press 1 to receive a call back la$
                <Say>Or press 9 to end this call.</Say>
        </Gather>

        <!-- If no customer input, prompt again. -->
        <Say>Sorry, I didn't get your response.</Say>
        <Redirect>welcome_customer.php</Redirect>
</Response>
